import { useState, useEffect, useRef } from 'react';
import { PRODUCTS, LOGO, resolveImg } from './products';

// ─── helpers ───────────────────────────────────────────────────
const fmt  = (n) => 'PKR ' + Number(n).toLocaleString();
const disc = (p, o) => Math.round((1 - p / o) * 100);

// ─── badge colours ─────────────────────────────────────────────
const BADGE = {
  New:        'bg-[#2C3022] text-[#D4AF7A]',
  Bestseller: 'bg-[#B8965A] text-white',
  Sale:       'bg-[#C4622D] text-white',
};

// ─── nav categories ────────────────────────────────────────────
const NAV = [
  { id:'women',     label:'Women',      hero:'https://images.unsplash.com/photo-1515886657613-9f3515b0c78f?auto=format&fit=crop&q=80&w=1600', accent:'#5C3050' },
  { id:'men',       label:'Men',        hero:'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&q=80&w=1600', accent:'#1B2A4A' },
  { id:'kids',      label:'Children',   hero:'https://images.unsplash.com/photo-1514533212735-5df27d970db0?auto=format&fit=crop&q=80&w=1600', accent:'#4A5030' },
  { id:'fabrics',   label:'Fabrics',    hero:null, accent:'#2C3022' },
  { id:'bedsheets', label:'Bed Sheets', hero:null, accent:'#3D2A1A' },
  { id:'towels',    label:'Towels',     hero:'https://images.unsplash.com/photo-1583845112203-29329902332e?auto=format&fit=crop&q=80&w=1600', accent:'#2A3A3A' },
];

// ─── toast ─────────────────────────────────────────────────────
function useToast() {
  const [t, setT] = useState(null);
  const show = (msg) => { setT(msg); setTimeout(() => setT(null), 2400); };
  return [t, show];
}

// ═══════════════════════════════════════════════════════════════
// APP ROOT
// ═══════════════════════════════════════════════════════════════
export default function App() {
  const [page,         setPage]         = useState('home');
  const [modal,        setModal]        = useState(null);
  const [cart,         setCart]         = useState([]);
  const [cartOpen,     setCartOpen]     = useState(false);
  const [wishlist,     setWishlist]     = useState([]);
  const [toast,        showToast]       = useToast();
  const [searchOpen,   setSearchOpen]   = useState(false);
  const [searchQ,      setSearchQ]      = useState('');
  const [checkoutOpen, setCheckoutOpen] = useState(false);

  const cartTotal = cart.reduce((s, i) => s + i.price * i.qty, 0);
  const cartCount = cart.reduce((s, i) => s + i.qty, 0);

  const addToCart = (product, qty = 1) => {
    setCart(prev => {
      const ex = prev.find(i => i.id === product.id);
      return ex
        ? prev.map(i => i.id === product.id ? { ...i, qty: i.qty + qty } : i)
        : [...prev, { ...product, qty }];
    });
    showToast(`${product.name} added to bag`);
    setCartOpen(true);
  };

  const removeFromCart = (id) => setCart(prev => prev.filter(i => i.id !== id));
  const updateQty = (id, d) =>
    setCart(prev => prev.map(i => i.id === id ? { ...i, qty: Math.max(1, i.qty + d) } : i));
  const clearCart = () => setCart([]);

  const toggleWish = (id) =>
    setWishlist(prev => prev.includes(id) ? prev.filter(x => x !== id) : [...prev, id]);

  const goTo = (p) => { setPage(p); window.scrollTo({ top: 0, behavior: 'smooth' }); };

  const searchResults = searchQ.length > 1
    ? PRODUCTS.filter(p =>
        p.name.toLowerCase().includes(searchQ.toLowerCase()) ||
        p.category.toLowerCase().includes(searchQ.toLowerCase())
      )
    : [];

  return (
    <div className="min-h-screen font-body bg-[#FDFAF6] text-[#1A1A1A] overflow-x-hidden">
      {/* promo bar */}
      <div className="bg-[#2C3022] text-[#D4AF7A] text-[10px] tracking-[0.22em] uppercase py-2.5 text-center px-4">
        Free Shipping on Orders Above PKR 3,000 &nbsp;·&nbsp; International Delivery &nbsp;·&nbsp; WhatsApp Orders Welcome
      </div>

      <Navbar goTo={goTo} page={page} cartCount={cartCount}
        onCartClick={() => setCartOpen(true)}
        onSearchClick={() => setSearchOpen(true)} />

      {searchOpen && (
        <SearchOverlay q={searchQ} setQ={setSearchQ} results={searchResults}
          onClose={() => { setSearchOpen(false); setSearchQ(''); }}
          onSelect={p => { setSearchOpen(false); setSearchQ(''); setModal(p); }} />
      )}

      <CartDrawer open={cartOpen} onClose={() => setCartOpen(false)}
        cart={cart} cartTotal={cartTotal}
        onRemove={removeFromCart} onUpdateQty={updateQty}
        onCheckout={() => { setCartOpen(false); setCheckoutOpen(true); }} />

      {checkoutOpen && (
        <CheckoutPage cart={cart} cartTotal={cartTotal}
          onClose={() => setCheckoutOpen(false)}
          onOrderPlaced={() => { clearCart(); setCheckoutOpen(false); showToast('Order placed! We will contact you shortly.'); }} />
      )}

      {modal && (
        <ProductModal product={modal} onClose={() => setModal(null)}
          onAdd={(p, q) => { addToCart(p, q); setModal(null); }}
          isWished={wishlist.includes(modal.id)}
          onToggleWish={() => toggleWish(modal.id)} />
      )}

      {toast && (
        <div className="fixed bottom-6 left-1/2 -translate-x-1/2 z-[300] bg-[#2C3022] text-[#D4AF7A] px-6 py-3 text-[11px] tracking-widest uppercase shadow-2xl animate-slideUp whitespace-nowrap">
          {toast}
        </div>
      )}

      {page === 'home' && <HomePage goTo={goTo} onProduct={setModal} onAdd={addToCart} wishlist={wishlist} onWish={toggleWish} />}
      {NAV.map(cat => page === cat.id &&
        <CategoryPage key={cat.id} cat={cat} onProduct={setModal} onAdd={addToCart} wishlist={wishlist} onWish={toggleWish} />
      )}
      {page === 'sale'  && <SalePage  onProduct={setModal} onAdd={addToCart} wishlist={wishlist} onWish={toggleWish} />}
      {page === 'about' && <AboutPage goTo={goTo} />}

      <SiteFooter goTo={goTo} />
    </div>
  );
}

// ═══════════════════════════════════════════════════════════════
// NAVBAR
// ═══════════════════════════════════════════════════════════════
function Navbar({ goTo, page, cartCount, onCartClick, onSearchClick }) {
  const left  = [{ id:'women', label:'Women' }, { id:'men', label:'Men' }, { id:'kids', label:'Children' }];
  const right = [{ id:'fabrics', label:'Fabrics' }, { id:'bedsheets', label:'Bed Sheets' }, { id:'towels', label:'Towels' }, { id:'sale', label:'Sale', red:true }, { id:'about', label:'About' }];

  return (
    <nav className="bg-white/96 backdrop-blur-md sticky top-0 z-50 border-b border-[#E8E0D5] shadow-sm">
      <div className="max-w-[1440px] mx-auto px-6 flex items-center justify-between h-[72px] gap-4">
        <div className="hidden lg:flex gap-6 items-center">
          {left.map(l => (
            <button key={l.id} onClick={() => goTo(l.id)}
              className={`text-[10.5px] font-semibold uppercase tracking-[0.18em] transition-colors ${page===l.id?'text-[#B8965A]':'text-[#1A1A1A] hover:text-[#B8965A]'}`}>
              {l.label}
            </button>
          ))}
        </div>

        <button onClick={() => goTo('home')} className="flex flex-col items-center leading-none shrink-0 mx-auto lg:mx-0">
          <img src={LOGO} alt="ARSAM" className="h-12 w-12 rounded-full object-cover border-2 border-[#B8965A]" />
          <span className="font-display text-[13px] tracking-[0.35em] text-[#2C3022] mt-0.5">ARSAM</span>
          <span className="text-[7px] tracking-[0.28em] text-[#B8965A] uppercase">Fabrics & Textiles</span>
        </button>

        <div className="hidden lg:flex gap-6 items-center">
          {right.map(l => (
            <button key={l.id} onClick={() => goTo(l.id)}
              className={`text-[10.5px] font-semibold uppercase tracking-[0.18em] transition-colors ${l.red?'text-[#C4622D]':page===l.id?'text-[#B8965A]':'text-[#1A1A1A] hover:text-[#B8965A]'}`}>
              {l.label}
            </button>
          ))}
        </div>

        <div className="flex items-center gap-3 lg:ml-4">
          <button onClick={onSearchClick} className="p-1.5 hover:text-[#B8965A] transition-colors"><SearchIcon /></button>
          <button onClick={onCartClick} className="relative p-1.5 hover:text-[#B8965A] transition-colors">
            <BagIcon />
            {cartCount > 0 && (
              <span className="absolute -top-1 -right-1 bg-[#B8965A] text-white text-[9px] font-bold rounded-full w-4 h-4 flex items-center justify-center">
                {cartCount > 9 ? '9+' : cartCount}
              </span>
            )}
          </button>
        </div>
      </div>

      {/* mobile scroll nav */}
      <div className="lg:hidden flex overflow-x-auto scrollbar-hide border-t border-[#E8E0D5] bg-white">
        {[...left,...right].map(l => (
          <button key={l.id} onClick={() => goTo(l.id)}
            className={`shrink-0 px-4 py-2.5 text-[9.5px] font-semibold uppercase tracking-[0.15em] whitespace-nowrap border-b-2 transition-colors ${page===l.id?'border-[#B8965A] text-[#B8965A]':'border-transparent text-gray-500'} ${l.red?'text-[#C4622D]':''}`}>
            {l.label}
          </button>
        ))}
      </div>
    </nav>
  );
}

// ═══════════════════════════════════════════════════════════════
// SEARCH
// ═══════════════════════════════════════════════════════════════
function SearchOverlay({ q, setQ, results, onClose, onSelect }) {
  const ref = useRef();
  useEffect(() => { ref.current?.focus(); }, []);
  return (
    <div className="fixed inset-0 z-[150] bg-black/70 backdrop-blur-sm flex flex-col items-center pt-24 px-4" onClick={onClose}>
      <div className="w-full max-w-2xl bg-white shadow-2xl" onClick={e => e.stopPropagation()}>
        <div className="flex items-center border-b border-[#E8E0D5] px-5">
          <SearchIcon className="text-[#B8965A] shrink-0" />
          <input ref={ref} value={q} onChange={e => setQ(e.target.value)}
            placeholder="Search products, categories…"
            className="flex-1 py-4 px-3 text-sm outline-none font-body bg-transparent" />
          <button onClick={onClose} className="p-2 hover:text-[#B8965A]"><XIcon /></button>
        </div>
        {results.length > 0 && (
          <ul className="max-h-80 overflow-y-auto divide-y divide-[#F0EBE4]">
            {results.map(p => (
              <li key={p.id} onClick={() => onSelect(p)}
                className="flex gap-4 items-center p-4 cursor-pointer hover:bg-[#F9F5EF] transition-colors">
                <img src={resolveImg(p.img)} alt={p.name} className="w-12 h-14 object-cover object-top bg-[#F0EBE4] shrink-0" />
                <div>
                  <div className="text-sm font-medium">{p.name}</div>
                  <div className="text-[10px] text-[#9A8878] uppercase tracking-wide mt-0.5 capitalize">{p.category} · {p.sub}</div>
                  <div className="text-xs text-[#B8965A] font-semibold mt-0.5">{fmt(p.price)}</div>
                </div>
              </li>
            ))}
          </ul>
        )}
        {q.length > 1 && results.length === 0 && (
          <p className="p-8 text-center text-sm text-gray-400">No results for "{q}"</p>
        )}
      </div>
    </div>
  );
}

// ═══════════════════════════════════════════════════════════════
// CART DRAWER
// ═══════════════════════════════════════════════════════════════
function CartDrawer({ open, onClose, cart, cartTotal, onRemove, onUpdateQty, onCheckout }) {
  const count = cart.reduce((s, i) => s + i.qty, 0);
  return (
    <>
      <div className={`fixed inset-0 z-[100] bg-black/50 backdrop-blur-sm transition-opacity duration-300 ${open?'opacity-100 pointer-events-auto':'opacity-0 pointer-events-none'}`}
        onClick={onClose} />
      <div className={`fixed top-0 right-0 h-full w-full max-w-[420px] z-[101] bg-white shadow-2xl flex flex-col transition-transform duration-350 ease-out ${open?'translate-x-0':'translate-x-full'}`}>
        <div className="flex items-center justify-between px-6 py-5 border-b border-[#E8E0D5]">
          <div>
            <h2 className="font-display text-2xl tracking-wide">Your Bag</h2>
            {count > 0 && <p className="text-[10px] text-[#B8965A] uppercase tracking-widest mt-0.5">{count} item{count!==1?'s':''}</p>}
          </div>
          <button onClick={onClose} className="p-2 hover:bg-[#F9F5EF] rounded-full transition-colors"><XIcon /></button>
        </div>

        <div className="flex-1 overflow-y-auto px-6 py-4 space-y-5">
          {cart.length === 0 ? (
            <div className="flex flex-col items-center justify-center h-full text-center gap-4 py-20">
              <BagIcon className="w-10 h-10 text-[#D4AF7A] opacity-30" />
              <p className="text-sm text-gray-400">Your bag is empty</p>
              <button onClick={onClose} className="text-[10px] uppercase tracking-widest text-[#B8965A] border border-[#B8965A] px-5 py-2.5 hover:bg-[#B8965A] hover:text-white transition-colors">
                Continue Shopping
              </button>
            </div>
          ) : cart.map(item => (
            <div key={item.id} className="flex gap-4 group">
              <img src={resolveImg(item.img)} alt={item.name}
                className="w-20 h-24 object-cover object-top bg-[#F0EBE4] shrink-0" />
              <div className="flex-1 min-w-0">
                <p className="text-[10px] text-[#B8965A] uppercase tracking-widest mb-0.5 capitalize">{item.category}</p>
                <h4 className="text-sm font-medium leading-snug pr-5">{item.name}</h4>
                <p className="text-xs text-gray-400 mt-0.5">{item.sub}</p>
                <div className="flex items-center justify-between mt-3">
                  <div className="flex items-center border border-[#E8E0D5]">
                    <button onClick={() => onUpdateQty(item.id, -1)}
                      className="w-7 h-7 flex items-center justify-center hover:bg-[#F9F5EF] transition-colors text-base leading-none">−</button>
                    <span className="w-7 h-7 flex items-center justify-center text-[11px] font-semibold border-x border-[#E8E0D5]">{item.qty}</span>
                    <button onClick={() => onUpdateQty(item.id, +1)}
                      className="w-7 h-7 flex items-center justify-center hover:bg-[#F9F5EF] transition-colors text-base leading-none">+</button>
                  </div>
                  <span className="text-sm font-semibold">{fmt(item.price * item.qty)}</span>
                </div>
              </div>
              <button onClick={() => onRemove(item.id)}
                className="self-start p-1 text-gray-300 hover:text-red-400 transition-colors opacity-0 group-hover:opacity-100 mt-0.5 shrink-0">
                <XIcon size={14} />
              </button>
            </div>
          ))}
        </div>

        {cart.length > 0 && (
          <div className="border-t border-[#E8E0D5] px-6 py-5 bg-[#FDFAF6] space-y-3">
            <div className="flex justify-between items-center">
              <span className="text-xs uppercase tracking-widest text-gray-400">Subtotal</span>
              <span className="font-display text-2xl">{fmt(cartTotal)}</span>
            </div>
            <p className="text-[10px] text-gray-400">Shipping calculated at checkout. Free above PKR 3,000.</p>
            <button onClick={onCheckout}
              className="w-full bg-[#2C3022] text-[#D4AF7A] py-4 text-[10.5px] font-bold uppercase tracking-[0.2em] hover:bg-[#1a1e15] transition-colors">
              Proceed to Checkout →
            </button>
            <a href={`https://wa.me/923001234567?text=Hi! I'd like to order: ${cart.map(i=>`${i.name} x${i.qty}`).join(', ')} — Total: PKR ${cartTotal.toLocaleString()}`}
              target="_blank" rel="noreferrer"
              className="flex items-center justify-center gap-2 w-full border border-[#2C3022] py-3 text-[10.5px] font-bold uppercase tracking-widest hover:bg-[#F0EBE4] transition-colors">
              <span>📱</span> Order via WhatsApp
            </a>
          </div>
        )}
      </div>
    </>
  );
}

// ═══════════════════════════════════════════════════════════════
// CHECKOUT PAGE
// ═══════════════════════════════════════════════════════════════
function CheckoutPage({ cart, cartTotal, onClose, onOrderPlaced }) {
  const shipping   = cartTotal >= 3000 ? 0 : 250;
  const grandTotal = cartTotal + shipping;

  const [step, setStep] = useState(1);
  const [form, setForm] = useState({
    name:'', phone:'', email:'', city:'', address:'', notes:'', payment:'cod',
  });
  const [errors, setErrors] = useState({});

  const set = (k, v) => { setForm(f => ({...f, [k]:v})); setErrors(e => ({...e, [k]:''})); };

  const validate1 = () => {
    const e = {};
    if (!form.name.trim())    e.name    = 'Full name is required';
    if (!form.phone.trim())   e.phone   = 'Phone number is required';
    if (!form.city.trim())    e.city    = 'City is required';
    if (!form.address.trim()) e.address = 'Delivery address is required';
    setErrors(e);
    return Object.keys(e).length === 0;
  };

  const placeOrder = () => {
    const items = cart.map(i=>`• ${i.name} x${i.qty} — PKR ${(i.price*i.qty).toLocaleString()}`).join('\n');
    const pay = { cod:'Cash on Delivery', jazz:'JazzCash', easy:'EasyPaisa', bank:'Bank Transfer' };
    const msg = encodeURIComponent(
      `🛍️ *New ARSAM Order*\n\n` +
      `*Name:* ${form.name}\n*Phone:* ${form.phone}\n*City:* ${form.city}\n*Address:* ${form.address}\n` +
      (form.notes?`*Notes:* ${form.notes}\n`:'') +
      `\n*Items:*\n${items}\n\n` +
      `*Subtotal:* PKR ${cartTotal.toLocaleString()}\n` +
      `*Shipping:* ${shipping===0?'FREE':'PKR '+shipping}\n` +
      `*Grand Total:* PKR ${grandTotal.toLocaleString()}\n` +
      `*Payment:* ${pay[form.payment]}`
    );
    window.open(`https://wa.me/923001234567?text=${msg}`, '_blank');
    setStep(3);
  };

  const FieldEl = ({ label, id, type='text', placeholder, half }) => (
    <div className={half?'col-span-1':'col-span-2'}>
      <label className="block text-[10px] uppercase tracking-widest text-gray-500 mb-1.5">{label}</label>
      <input type={type} placeholder={placeholder} value={form[id]} onChange={e => set(id, e.target.value)}
        className={`w-full border px-4 py-3 text-sm font-body outline-none transition-colors bg-white ${errors[id]?'border-red-400':'border-[#D0C8BF] focus:border-[#B8965A]'}`} />
      {errors[id] && <p className="text-[10px] text-red-500 mt-1">{errors[id]}</p>}
    </div>
  );

  return (
    <div className="fixed inset-0 z-[200] bg-[#FDFAF6] overflow-y-auto">
      {/* sticky header */}
      <div className="bg-white border-b border-[#E8E0D5] sticky top-0 z-10 shadow-sm">
        <div className="max-w-5xl mx-auto px-6 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <img src={LOGO} alt="ARSAM" className="w-9 h-9 rounded-full object-cover border border-[#B8965A]" />
            <div>
              <p className="font-display text-lg tracking-wide">ARSAM Checkout</p>
              {step < 3 && <p className="text-[9px] uppercase tracking-widest text-gray-400">Secure Order</p>}
            </div>
          </div>
          <button onClick={onClose} className="flex items-center gap-1.5 text-[10.5px] uppercase tracking-widest text-gray-400 hover:text-[#B8965A] transition-colors">
            <XIcon size={13} /> Back
          </button>
        </div>

        {step < 3 && (
          <div className="max-w-5xl mx-auto px-6 pb-3.5 flex items-center gap-2">
            {['Delivery','Payment'].map((s,i) => (
              <div key={s} className="flex items-center gap-2">
                {i>0 && <div className={`h-px w-8 transition-colors ${step>i?'bg-[#B8965A]':'bg-[#E0D8D0]'}`} />}
                <div className={`flex items-center gap-2 cursor-pointer`} onClick={() => i===0 && setStep(1)}>
                  <div className={`w-5 h-5 rounded-full flex items-center justify-center text-[9px] font-bold transition-colors ${step===i+1?'bg-[#2C3022] text-[#D4AF7A]':step>i+1?'bg-[#B8965A] text-white':'bg-[#E0D8D0] text-gray-400'}`}>{step>i+1?'✓':i+1}</div>
                  <span className={`text-[10.5px] uppercase tracking-widest transition-colors ${step===i+1?'text-[#2C3022] font-semibold':'text-gray-400'}`}>{s}</span>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      <div className="max-w-5xl mx-auto px-4 lg:px-6 py-8 grid lg:grid-cols-[1fr_380px] gap-8 items-start">

        {/* ── STEP 1 — delivery ── */}
        {step === 1 && (
          <div>
            <h2 className="font-display text-2xl mb-6">Delivery Information</h2>
            <div className="grid grid-cols-2 gap-4">
              <FieldEl label="Full Name *" id="name" placeholder="e.g. Fatima Khan" />
              <FieldEl label="Phone Number *" id="phone" type="tel" placeholder="0300-1234567" half />
              <FieldEl label="Email Address" id="email" type="email" placeholder="optional — for order updates" half />
              <FieldEl label="City *" id="city" placeholder="e.g. Karachi, Lahore…" half />
              <FieldEl label="Delivery Address *" id="address" placeholder="House/Flat, Street, Area, Landmark" />
              <div className="col-span-2">
                <label className="block text-[10px] uppercase tracking-widest text-gray-500 mb-1.5">Special Instructions</label>
                <textarea value={form.notes} onChange={e => set('notes', e.target.value)} rows={3}
                  placeholder="Preferred delivery time, colour preference, gift wrapping…"
                  className="w-full border border-[#D0C8BF] px-4 py-3 text-sm font-body outline-none resize-none focus:border-[#B8965A] transition-colors" />
              </div>
            </div>
            <button onClick={() => { if(validate1()) setStep(2); }}
              className="mt-6 w-full bg-[#2C3022] text-[#D4AF7A] py-4 text-[10.5px] font-bold uppercase tracking-[0.2em] hover:bg-[#1a1e15] transition-colors">
              Continue to Payment →
            </button>
            <a href={`https://wa.me/923001234567?text=Hi! I'd like to order: ${cart.map(i=>`${i.name} x${i.qty}`).join(', ')}`}
              target="_blank" rel="noreferrer"
              className="mt-3 flex items-center justify-center gap-2 w-full border border-[#2C3022] py-3 text-[10.5px] font-bold uppercase tracking-widest hover:bg-[#F0EBE4] transition-colors">
              <span>📱</span> Skip & Order via WhatsApp
            </a>
          </div>
        )}

        {/* ── STEP 2 — payment ── */}
        {step === 2 && (
          <div>
            <button onClick={() => setStep(1)} className="flex items-center gap-2 text-[10px] uppercase tracking-widest text-gray-400 hover:text-[#B8965A] mb-5 transition-colors">
              ← Edit Delivery
            </button>

            {/* delivery summary */}
            <div className="bg-[#F9F5EF] border border-[#E8E0D5] p-4 mb-6 text-sm">
              <div className="flex items-center justify-between mb-1">
                <p className="text-[10px] uppercase tracking-widest text-[#B8965A]">Delivering to</p>
                <button onClick={() => setStep(1)} className="text-[10px] uppercase tracking-widest text-gray-400 hover:text-[#B8965A] underline">Edit</button>
              </div>
              <p className="font-medium">{form.name} · {form.phone}</p>
              <p className="text-gray-500 text-xs mt-0.5">{form.address}, {form.city}</p>
            </div>

            <h2 className="font-display text-2xl mb-5">Payment Method</h2>
            <div className="space-y-3 mb-6">
              {[
                { id:'cod',  label:'Cash on Delivery',  desc:'Pay when your order arrives at your door', icon:'💵' },
                { id:'jazz', label:'JazzCash',           desc:'Pay via JazzCash mobile wallet', icon:'📱' },
                { id:'easy', label:'EasyPaisa',          desc:'Pay via EasyPaisa mobile account', icon:'💳' },
                { id:'bank', label:'Bank Transfer',      desc:'Direct bank transfer — details via WhatsApp', icon:'🏦' },
              ].map(pm => (
                <label key={pm.id}
                  className={`flex items-center gap-4 p-4 border cursor-pointer transition-all ${form.payment===pm.id?'border-[#B8965A] bg-[#FBF7F2] shadow-sm':'border-[#E8E0D5] hover:border-[#D0C8BF]'}`}>
                  <input type="radio" name="payment" value={pm.id} checked={form.payment===pm.id}
                    onChange={() => set('payment', pm.id)} className="accent-[#B8965A]" />
                  <span className="text-xl">{pm.icon}</span>
                  <div className="flex-1">
                    <p className="text-sm font-semibold">{pm.label}</p>
                    <p className="text-[11px] text-gray-400 mt-0.5">{pm.desc}</p>
                  </div>
                  {form.payment===pm.id && <span className="text-[#B8965A] font-bold">✓</span>}
                </label>
              ))}
            </div>

            {(form.payment==='jazz'||form.payment==='easy') && (
              <div className="bg-amber-50 border border-amber-200 p-4 mb-5 text-sm text-amber-800 flex gap-3">
                <span>📲</span>
                <span>After placing your order, our team will send you the payment account number via WhatsApp.</span>
              </div>
            )}
            {form.payment==='bank' && (
              <div className="bg-sky-50 border border-sky-200 p-4 mb-5 text-sm text-sky-800 flex gap-3">
                <span>🏦</span>
                <span>Bank details will be shared on WhatsApp after your order is confirmed.</span>
              </div>
            )}

            <button onClick={placeOrder}
              className="w-full bg-[#B8965A] text-white py-4 text-[10.5px] font-bold uppercase tracking-[0.2em] hover:bg-[#D4AF7A] transition-colors">
              Place Order · {fmt(grandTotal)} →
            </button>
            <p className="text-[10px] text-center text-gray-400 mt-3 leading-relaxed">
              Your order summary will be sent to our WhatsApp for confirmation. We'll reach out within 24 hours.
            </p>
          </div>
        )}

        {/* ── STEP 3 — success ── */}
        {step === 3 && (
          <div className="text-center py-10 lg:py-16">
            <div className="w-20 h-20 bg-green-50 border-2 border-green-200 rounded-full flex items-center justify-center text-3xl mx-auto mb-6">✓</div>
            <h2 className="font-display text-3xl text-[#2C3022] mb-3">Order Received!</h2>
            <p className="text-gray-500 text-sm leading-relaxed max-w-sm mx-auto mb-8">
              Your order has been sent to our team via WhatsApp. We'll confirm it and arrange delivery within 24 hours.
            </p>
            <div className="bg-[#F9F5EF] border border-[#E8E0D5] p-5 text-left max-w-xs mx-auto mb-8">
              <p className="text-[10px] uppercase tracking-widest text-[#B8965A] mb-3">Confirmation Details</p>
              <p className="text-sm"><span className="text-gray-400">Name: </span>{form.name}</p>
              <p className="text-sm mt-1"><span className="text-gray-400">Phone: </span>{form.phone}</p>
              <p className="text-sm mt-1"><span className="text-gray-400">City: </span>{form.city}</p>
              <p className="text-sm mt-2 font-semibold"><span className="text-gray-400 font-normal">Total: </span>{fmt(grandTotal)}</p>
            </div>
            <button onClick={onOrderPlaced}
              className="bg-[#2C3022] text-[#D4AF7A] px-10 py-4 text-[10.5px] font-bold uppercase tracking-widest hover:bg-[#1a1e15] transition-colors">
              Continue Shopping
            </button>
          </div>
        )}

        {/* ── order summary sidebar ── */}
        <div className="bg-white border border-[#E8E0D5] p-6 self-start lg:sticky lg:top-[120px]">
          <h3 className="font-display text-lg mb-4 pb-3 border-b border-[#E8E0D5]">
            Order Summary <span className="text-sm font-body text-gray-400 ml-1">({cart.reduce((s,i)=>s+i.qty,0)} items)</span>
          </h3>
          <div className="space-y-4 max-h-64 overflow-y-auto pr-1 mb-4">
            {cart.map(item => (
              <div key={item.id} className="flex gap-3 items-start">
                <div className="relative shrink-0">
                  <img src={resolveImg(item.img)} alt={item.name} className="w-14 h-16 object-cover object-top bg-[#F0EBE4]" />
                  <span className="absolute -top-1.5 -right-1.5 bg-[#2C3022] text-white text-[8px] w-4 h-4 rounded-full flex items-center justify-center font-bold">{item.qty}</span>
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-[11px] font-medium leading-snug">{item.name}</p>
                  <p className="text-[10px] text-gray-400 mt-0.5">{item.sub}</p>
                </div>
                <span className="text-[12px] font-semibold shrink-0 tabular-nums">{fmt(item.price*item.qty)}</span>
              </div>
            ))}
          </div>
          <div className="border-t border-[#E8E0D5] pt-4 space-y-2 text-sm">
            <div className="flex justify-between text-gray-500"><span>Subtotal</span><span>{fmt(cartTotal)}</span></div>
            <div className="flex justify-between text-gray-500">
              <span>Shipping</span>
              <span className={shipping===0?'text-green-600 font-semibold':''}>{shipping===0?'FREE':fmt(shipping)}</span>
            </div>
            {shipping > 0 && <p className="text-[9.5px] text-gray-400">Add PKR {fmt(3000-cartTotal).replace('PKR ','')} more for free shipping</p>}
            <div className="flex justify-between font-semibold text-base border-t border-[#E8E0D5] pt-3 mt-1">
              <span>Total</span>
              <span className="font-display text-xl">{fmt(grandTotal)}</span>
            </div>
          </div>
          <div className="mt-4 pt-3 border-t border-[#E8E0D5] flex flex-wrap gap-1.5">
            {['JazzCash','EasyPaisa','Bank','COD'].map(b=>(
              <span key={b} className="text-[8.5px] border border-[#E0D8D0] px-2 py-0.5 text-gray-400 uppercase tracking-wide">{b}</span>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

// ═══════════════════════════════════════════════════════════════
// PRODUCT MODAL
// ═══════════════════════════════════════════════════════════════
function ProductModal({ product: p, onClose, onAdd, isWished, onToggleWish }) {
  const [qty, setQty] = useState(1);
  return (
    <div className="fixed inset-0 z-[120] flex items-center justify-center p-4 lg:p-8">
      <div className="absolute inset-0 bg-black/65 backdrop-blur-sm" onClick={onClose} />
      <div className="relative bg-white w-full max-w-5xl max-h-[95vh] overflow-hidden shadow-2xl grid md:grid-cols-2 z-10">
        <div className="relative overflow-hidden h-64 md:h-auto">
          <img src={resolveImg(p.img)} alt={p.name} className="w-full h-full object-cover object-top" />
          {p.badge && <span className={`absolute top-4 left-4 px-3 py-1 text-[9px] font-bold uppercase tracking-widest ${BADGE[p.badge]||'bg-gray-700 text-white'}`}>{p.badge}</span>}
          {p.oldPrice && <div className="absolute bottom-4 left-4 bg-[#C4622D] text-white px-3 py-1.5 text-[10.5px] font-bold">{disc(p.price,p.oldPrice)}% OFF</div>}
        </div>
        <div className="overflow-y-auto p-7 lg:p-10 flex flex-col">
          <button onClick={onClose} className="self-end p-1.5 hover:bg-[#F9F5EF] rounded-full mb-4 -mr-2 transition-colors"><XIcon /></button>
          <p className="text-[10px] text-[#B8965A] font-bold uppercase tracking-widest mb-1.5 capitalize">{p.category} · {p.sub}</p>
          <h2 className="font-display text-2xl lg:text-3xl leading-tight mb-3">{p.name}</h2>
          <div className="flex items-baseline gap-3 mb-5 flex-wrap">
            <span className="text-2xl font-semibold">{fmt(p.price)}</span>
            {p.oldPrice && <>
              <span className="text-sm text-gray-400 line-through">{fmt(p.oldPrice)}</span>
              <span className="text-sm text-[#C4622D] font-semibold">{disc(p.price,p.oldPrice)}% off</span>
            </>}
          </div>
          <p className="text-sm text-gray-500 leading-relaxed mb-6">{p.description}</p>
          {p.fabrics?.length > 0 && (
            <div className="mb-6">
              <p className="text-[10px] font-bold uppercase tracking-widest text-[#2C3022] mb-2">Includes</p>
              <ul className="text-xs text-gray-500 space-y-1.5">
                {p.fabrics.map((f,i) => <li key={i} className="flex items-center gap-2"><span className="w-1 h-1 rounded-full bg-[#B8965A] shrink-0" />{f}</li>)}
              </ul>
            </div>
          )}
          <div className="flex items-center gap-4 mb-6">
            <p className="text-[10px] font-bold uppercase tracking-widest">Qty</p>
            <div className="flex items-center border border-[#D0C8BF]">
              <button onClick={() => setQty(q => Math.max(1,q-1))} className="w-9 h-9 flex items-center justify-center hover:bg-[#F9F5EF] transition-colors text-lg">−</button>
              <span className="w-9 h-9 flex items-center justify-center text-sm font-semibold border-x border-[#D0C8BF]">{qty}</span>
              <button onClick={() => setQty(q => q+1)} className="w-9 h-9 flex items-center justify-center hover:bg-[#F9F5EF] transition-colors text-lg">+</button>
            </div>
          </div>
          <div className="flex gap-3 mt-auto">
            <button onClick={() => onAdd(p, qty)}
              className="flex-1 bg-[#2C3022] text-[#D4AF7A] py-4 text-[10.5px] font-bold uppercase tracking-[0.2em] hover:bg-[#1a1e15] transition-colors">
              Add to Bag
            </button>
            <button onClick={onToggleWish}
              className={`w-14 flex items-center justify-center border transition-colors ${isWished?'bg-[#B8965A] border-[#B8965A] text-white':'border-[#D0C8BF] hover:border-[#B8965A] hover:text-[#B8965A]'}`}>
              <HeartIcon size={16} filled={isWished} />
            </button>
          </div>
          <a href={`https://wa.me/923001234567?text=Hi! I'm interested in ${p.name} (${fmt(p.price)})`}
            target="_blank" rel="noreferrer"
            className="mt-3 flex items-center justify-center gap-2 border border-[#2C3022] py-3 text-[10.5px] font-bold uppercase tracking-widest hover:bg-[#F9F5EF] transition-colors">
            <span>📱</span> Order via WhatsApp
          </a>
        </div>
      </div>
    </div>
  );
}

// ═══════════════════════════════════════════════════════════════
// PRODUCT CARD
// ═══════════════════════════════════════════════════════════════
function ProductCard({ product: p, onProduct, onAdd, isWished, onWish }) {
  return (
    <div className="group cursor-pointer">
      <div className="relative overflow-hidden bg-[#F0EBE4] mb-3" style={{aspectRatio:'2/3'}}
        onClick={() => onProduct(p)}>
        <img src={resolveImg(p.img)} alt={p.name}
          className="w-full h-full object-cover object-top transition-transform duration-700 group-hover:scale-[1.06]"
          loading="lazy" />
        {p.badge && <span className={`absolute top-3 left-3 px-2.5 py-0.5 text-[9px] font-bold uppercase tracking-widest ${BADGE[p.badge]||'bg-gray-700 text-white'}`}>{p.badge}</span>}
        {p.oldPrice && <span className="absolute top-3 right-3 bg-[#C4622D] text-white text-[9px] font-bold px-2 py-0.5">{disc(p.price,p.oldPrice)}%</span>}
        <button onClick={e => { e.stopPropagation(); onWish(p.id); }}
          className={`absolute ${p.oldPrice?'top-9':'top-3'} right-3 w-8 h-8 flex items-center justify-center rounded-full shadow-sm transition-all duration-200 ${isWished?'bg-[#B8965A] text-white opacity-100':'bg-white/80 text-gray-400 opacity-0 group-hover:opacity-100 hover:text-[#B8965A]'}`}>
          <HeartIcon size={13} filled={isWished} />
        </button>
        <div className="absolute inset-x-0 bottom-0 translate-y-full group-hover:translate-y-0 transition-transform duration-300 bg-gradient-to-t from-black/65 via-black/15 to-transparent pt-10 pb-3 px-3">
          <button onClick={e => { e.stopPropagation(); onAdd(p); }}
            className="w-full bg-white text-[#1A1A1A] py-2.5 text-[9px] font-bold uppercase tracking-widest hover:bg-[#B8965A] hover:text-white transition-colors">
            Quick Add
          </button>
        </div>
      </div>
      <div onClick={() => onProduct(p)}>
        <h3 className="text-[13px] font-medium leading-snug">{p.name}</h3>
        <p className="text-[10px] text-[#9A8878] uppercase tracking-wide mt-0.5 mb-1.5">{p.sub}</p>
        <div className="flex items-center gap-2 flex-wrap">
          <span className="text-sm font-semibold">{fmt(p.price)}</span>
          {p.oldPrice && <span className="text-xs text-gray-400 line-through">{fmt(p.oldPrice)}</span>}
        </div>
      </div>
    </div>
  );
}

// ═══════════════════════════════════════════════════════════════
// HOME PAGE
// ═══════════════════════════════════════════════════════════════
function HomePage({ goTo, onProduct, onAdd, wishlist, onWish }) {
  const [slide, setSlide] = useState(0);
  const slides = [
    { img:'https://images.unsplash.com/photo-1469334031218-e382a71b716b?auto=format&fit=crop&q=85&w=1800', tag:'Summer Collection 2024', title:'Elegance in\nEvery Thread', sub:'Authentic Pakistani lawn suits, premium khaddar & embroidered formals', cta1:{label:'Shop Women',page:'women'}, cta2:{label:'Shop Men',page:'men'} },
    { img:'https://images.unsplash.com/photo-1583845112203-29329902332e?auto=format&fit=crop&q=85&w=1800', tag:'New — Home Essentials', title:'Wrap Yourself\nin Luxury', sub:'Premium cotton towels & bed sets — hotel quality comfort for your home', cta1:{label:'Shop Towels',page:'towels'}, cta2:{label:'Bed Sheets',page:'bedsheets'} },
    { img:'https://images.unsplash.com/photo-1514533212735-5df27d970db0?auto=format&fit=crop&q=85&w=1800', tag:'Kids & Children', title:'Little Ones,\nBig Style', sub:'Adorable ethnic wear for children aged 1–14 · Girls, Boys & festive sets', cta1:{label:'Shop Children',page:'kids'}, cta2:{label:'View Sale',page:'sale'} },
  ];
  useEffect(() => {
    const t = setInterval(() => setSlide(s => (s+1)%slides.length), 5500);
    return () => clearInterval(t);
  }, []);

  const newArrivals = PRODUCTS.filter(p => p.badge === 'New').slice(0, 8);
  const featured    = PRODUCTS.filter(p => p.category === 'bedsheets').slice(0, 4);
  const towels      = PRODUCTS.filter(p => p.category === 'towels');

  return (
    <>
      {/* hero slider */}
      <div className="relative h-[82vh] min-h-[480px] overflow-hidden">
        {slides.map((s,i) => (
          <div key={i} className={`absolute inset-0 transition-opacity duration-1000 ${i===slide?'opacity-100':'opacity-0'}`}>
            <img src={s.img} alt="" className="w-full h-full object-cover object-center" />
            <div className="absolute inset-0 bg-gradient-to-r from-black/65 via-black/20 to-transparent" />
            <div className={`absolute left-10 lg:left-20 top-1/2 -translate-y-1/2 text-white max-w-xl transition-all duration-700 ${i===slide?'opacity-100 translate-x-0':'opacity-0 -translate-x-6'}`}>
              <p className="text-[10px] uppercase tracking-[0.35em] text-[#D4AF7A] mb-4">{s.tag}</p>
              <h1 className="font-display text-[clamp(40px,5.5vw,76px)] font-light leading-[1.05] mb-5 whitespace-pre-line">{s.title}</h1>
              <p className="text-sm text-white/70 leading-relaxed mb-8 max-w-sm">{s.sub}</p>
              <div className="flex gap-3 flex-wrap">
                <button onClick={() => goTo(s.cta1.page)} className="px-8 py-3.5 bg-[#B8965A] text-white text-[10.5px] font-bold uppercase tracking-widest hover:bg-[#D4AF7A] transition-colors">{s.cta1.label}</button>
                <button onClick={() => goTo(s.cta2.page)} className="px-8 py-3.5 border border-white/60 text-white text-[10.5px] font-bold uppercase tracking-widest hover:bg-white/10 transition-colors">{s.cta2.label}</button>
              </div>
            </div>
          </div>
        ))}
        <div className="absolute bottom-6 right-8 flex gap-2">
          {slides.map((_,i) => (
            <button key={i} onClick={() => setSlide(i)}
              className={`transition-all duration-300 rounded-full ${i===slide?'w-6 h-2 bg-[#B8965A]':'w-2 h-2 bg-white/40 hover:bg-white/70'}`} />
          ))}
        </div>
      </div>

      {/* category tiles */}
      <section className="max-w-[1440px] mx-auto px-6 py-16">
        <div className="text-center mb-10">
          <p className="text-[10px] uppercase tracking-[0.3em] text-[#B8965A] mb-2">Browse</p>
          <h2 className="font-display text-4xl text-[#2C3022]">Everything at <em className="text-[#B8965A]">ARSAM</em></h2>
        </div>
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3">
          {[
            { id:'women',     label:'Women',      img:'https://images.unsplash.com/photo-1485968579580-b6d095142e6e?auto=format&fit=crop&q=80&w=500' },
            { id:'men',       label:'Men',        img:'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&q=80&w=500' },
            { id:'kids',      label:'Children',   img:'https://images.unsplash.com/photo-1514533212735-5df27d970db0?auto=format&fit=crop&q=80&w=500' },
            { id:'fabrics',   label:'Fabrics',    img:resolveImg('__FABRIC__') },
            { id:'bedsheets', label:'Bed Sheets', img:resolveImg('__BED6__') },
            { id:'towels',    label:'Towels',     img:'https://images.unsplash.com/photo-1583845112203-29329902332e?auto=format&fit=crop&q=80&w=500' },
          ].map(c => (
            <button key={c.id} onClick={() => goTo(c.id)}
              className="relative overflow-hidden group" style={{aspectRatio:'3/4'}}>
              <img src={c.img} alt={c.label} className="w-full h-full object-cover object-center transition-transform duration-700 group-hover:scale-105" loading="lazy" />
              <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/10 to-transparent" />
              <div className="absolute inset-x-0 bottom-0 p-4 text-white text-left">
                <p className="font-display text-lg leading-tight">{c.label}</p>
                <p className="text-[8.5px] uppercase tracking-widest text-white/50 mt-0.5 opacity-0 group-hover:opacity-100 transition-opacity">Shop →</p>
              </div>
            </button>
          ))}
        </div>
      </section>

      {/* new arrivals */}
      <section className="max-w-[1440px] mx-auto px-6 pb-16">
        <SectionHeader eyebrow="Just Landed" title="New Arrivals" cta={{ label:'View All', onClick:()=>goTo('women') }} />
        <div className="grid grid-cols-2 md:grid-cols-4 gap-x-4 gap-y-8">
          {newArrivals.map(p => <ProductCard key={p.id} product={p} onProduct={onProduct} onAdd={onAdd} isWished={wishlist.includes(p.id)} onWish={onWish} />)}
        </div>
      </section>

      {/* editorial banner */}
      <section className="mx-4 lg:mx-8 mb-16 relative h-72 lg:h-[400px] overflow-hidden">
        <img src="https://images.unsplash.com/photo-1529626455594-4ff0802cfb7e?auto=format&fit=crop&q=80&w=1600" alt="" className="w-full h-full object-cover object-top" />
        <div className="absolute inset-0 bg-gradient-to-r from-[#2C3022]/90 to-transparent flex items-center px-10 lg:px-16">
          <div className="text-white max-w-sm">
            <p className="text-[10px] uppercase tracking-[0.35em] text-[#D4AF7A] mb-3">Est. 2020</p>
            <h2 className="font-display text-3xl lg:text-4xl font-light leading-tight mb-4">Woven with Pride<br/>in Pakistan</h2>
            <p className="text-sm text-white/65 leading-relaxed mb-6">From Pakistan's finest mills to homes worldwide — innovation, quality, and exceptional craftsmanship in every thread.</p>
            <button onClick={() => goTo('about')} className="px-7 py-3 bg-[#B8965A] text-white text-[10.5px] font-bold uppercase tracking-widest hover:bg-[#D4AF7A] transition-colors">Our Story</button>
          </div>
        </div>
      </section>

      {/* towels spotlight */}
      <section className="bg-[#F0EBE4] py-14 px-6">
        <div className="max-w-[1440px] mx-auto">
          <SectionHeader eyebrow="New Category" title="Premium Towels" cta={{ label:'Shop All Towels', onClick:()=>goTo('towels') }} />
          <div className="grid grid-cols-2 md:grid-cols-3 gap-x-4 gap-y-8">
            {towels.map(p => <ProductCard key={p.id} product={p} onProduct={onProduct} onAdd={onAdd} isWished={wishlist.includes(p.id)} onWish={onWish} />)}
          </div>
        </div>
      </section>

      {/* bed sheets */}
      <section className="max-w-[1440px] mx-auto px-6 py-14">
        <SectionHeader eyebrow="For Your Home" title="Premium Bed Sets" cta={{ label:'All Bed Sheets', onClick:()=>goTo('bedsheets') }} />
        <div className="grid grid-cols-2 md:grid-cols-4 gap-x-4 gap-y-8">
          {featured.map(p => <ProductCard key={p.id} product={p} onProduct={onProduct} onAdd={onAdd} isWished={wishlist.includes(p.id)} onWish={onWish} />)}
        </div>
      </section>

      <FeaturesStrip />
      <TestimonialsSection />
      <NewsletterSection />
    </>
  );
}

// ═══════════════════════════════════════════════════════════════
// CATEGORY PAGE
// ═══════════════════════════════════════════════════════════════
function CategoryPage({ cat, onProduct, onAdd, wishlist, onWish }) {
  const all = PRODUCTS.filter(p => p.category === cat.id);
  const [filter, setFilter] = useState('All');
  const shown = filter === 'All' ? all : all.filter(p => p.badge === filter);

  return (
    <>
      <div className="relative h-52 lg:h-64 overflow-hidden" style={{background: cat.accent}}>
        {cat.hero && <img src={cat.hero} alt={cat.label} className="w-full h-full object-cover object-top opacity-35" />}
        <div className="absolute inset-0 flex flex-col items-center justify-center text-white text-center px-4">
          <p className="text-[10px] uppercase tracking-[0.35em] text-[#D4AF7A] mb-2">ARSAM Collection</p>
          <h1 className="font-display text-4xl lg:text-5xl font-light">{cat.label}</h1>
          <p className="text-white/50 text-[11px] tracking-widest mt-2 uppercase">{all.length} Products</p>
        </div>
      </div>

      <div className="border-b border-[#E8E0D5] bg-white sticky top-[104px] z-30">
        <div className="max-w-[1440px] mx-auto px-6 flex gap-2 overflow-x-auto py-3 scrollbar-hide items-center">
          {['All','New','Bestseller','Sale'].map(f => (
            <button key={f} onClick={() => setFilter(f)}
              className={`shrink-0 px-5 py-2 text-[10px] font-semibold uppercase tracking-widest transition-all ${filter===f?'bg-[#2C3022] text-[#D4AF7A]':'border border-[#E8E0D5] text-gray-500 hover:border-[#2C3022] hover:text-[#2C3022]'}`}>
              {f}
            </button>
          ))}
          <span className="ml-auto shrink-0 text-[10px] text-gray-400 uppercase tracking-widest">{shown.length} items</span>
        </div>
      </div>

      <div className="max-w-[1440px] mx-auto px-6 py-12">
        {shown.length === 0
          ? <p className="text-center text-gray-400 py-24 text-sm">No {filter} products in this category</p>
          : <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-x-4 gap-y-10">
              {shown.map(p => <ProductCard key={p.id} product={p} onProduct={onProduct} onAdd={onAdd} isWished={wishlist.includes(p.id)} onWish={onWish} />)}
            </div>
        }
      </div>
      <FeaturesStrip />
    </>
  );
}

// ═══════════════════════════════════════════════════════════════
// SALE PAGE
// ═══════════════════════════════════════════════════════════════
function SalePage({ onProduct, onAdd, wishlist, onWish }) {
  const sale = PRODUCTS.filter(p => p.badge === 'Sale' || p.oldPrice);
  return (
    <>
      <div className="bg-[#C4622D] py-14 text-center text-white">
        <p className="text-[10px] uppercase tracking-[0.35em] text-white/60 mb-2">Limited Time</p>
        <h1 className="font-display text-4xl lg:text-5xl font-light">Mid-Season <em>Sale</em></h1>
        <p className="text-white/55 text-sm mt-2">{sale.length} products · Up to 40% off</p>
      </div>
      <div className="max-w-[1440px] mx-auto px-6 py-12">
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-x-4 gap-y-10">
          {sale.map(p => <ProductCard key={p.id} product={p} onProduct={onProduct} onAdd={onAdd} isWished={wishlist.includes(p.id)} onWish={onWish} />)}
        </div>
      </div>
      <FeaturesStrip />
    </>
  );
}

// ═══════════════════════════════════════════════════════════════
// ABOUT PAGE
// ═══════════════════════════════════════════════════════════════
function AboutPage({ goTo }) {
  return (
    <>
      <div className="bg-[#2C3022] h-48 flex items-center justify-center text-center">
        <div>
          <p className="text-[10px] uppercase tracking-[0.35em] text-[#D4AF7A] mb-2">Our Story</p>
          <h1 className="font-display text-4xl text-white font-light">About <em className="text-[#D4AF7A]">ARSAM</em></h1>
        </div>
      </div>
      <div className="max-w-4xl mx-auto px-6 py-16">
        <div className="flex flex-col md:flex-row gap-12 items-center mb-16">
          <img src={LOGO} alt="ARSAM" className="w-40 h-40 rounded-full object-cover border-4 border-[#B8965A] shadow-xl shrink-0" />
          <div>
            <p className="text-[10px] uppercase tracking-[0.3em] text-[#B8965A] mb-3">Since 2020</p>
            <h2 className="font-display text-3xl text-[#2C3022] mb-4">ARSAM Fabrics &amp; Textiles Ltd</h2>
            <p className="text-sm text-gray-500 leading-relaxed mb-3">Founded in 2020, ARSAM was born from a passion for quality Pakistani textiles. We believe every home and every person deserves the finest fabrics — from soft towels and bed sets to the most vibrant clothing prints.</p>
            <p className="text-sm text-gray-500 leading-relaxed">We source directly from Pakistan's premier textile mills, ensuring authenticity and quality in every product — women's embroidered lawn, men's khaddar, children's festive wear, premium bed linen, and luxurious bath towels.</p>
          </div>
        </div>
        <div className="grid grid-cols-3 gap-8 text-center border-t border-b border-[#E8E0D5] py-12 mb-16">
          {[['10,000+','Happy Customers'],['500+','Products'],['2020','Est. Since']].map(([n,l]) => (
            <div key={l}><p className="font-display text-4xl text-[#B8965A]">{n}</p><p className="text-[10.5px] uppercase tracking-widest text-gray-400 mt-2">{l}</p></div>
          ))}
        </div>
        <div className="grid md:grid-cols-3 gap-6">
          {[['⚡ Innovation','We stay ahead of trends, introducing fresh designs and modern cuts each season.'],['✦ Quality','Every product passes rigorous quality checks before leaving our facility.'],['◎ Optimization','Efficient sourcing keeps our prices fair without compromising quality.']].map(([t,d]) => (
            <div key={t} className="text-center p-6 border border-[#E8E0D5]">
              <p className="font-display text-xl text-[#B8965A] mb-3">{t}</p>
              <p className="text-sm text-gray-500 leading-relaxed">{d}</p>
            </div>
          ))}
        </div>
      </div>
      <FeaturesStrip />
    </>
  );
}

// ═══════════════════════════════════════════════════════════════
// SHARED
// ═══════════════════════════════════════════════════════════════
function SectionHeader({ eyebrow, title, cta }) {
  return (
    <div className="flex items-end justify-between mb-8">
      <div>
        <p className="text-[10px] uppercase tracking-[0.3em] text-[#B8965A] mb-1">{eyebrow}</p>
        <h2 className="font-display text-3xl text-[#2C3022]">{title}</h2>
      </div>
      {cta && <button onClick={cta.onClick} className="text-[10px] uppercase tracking-widest text-[#B8965A] underline underline-offset-4 hidden sm:block hover:text-[#D4AF7A] transition-colors">{cta.label}</button>}
    </div>
  );
}

function FeaturesStrip() {
  return (
    <div className="bg-[#2C3022] py-12">
      <div className="max-w-[1440px] mx-auto px-6 grid grid-cols-2 lg:grid-cols-4 gap-6">
        {[{icon:'🚚',t:'Nationwide Delivery',d:'Fast shipping across all of Pakistan'},{icon:'🛡️',t:'100% Authentic',d:'Genuine fabrics from verified mills'},{icon:'↩️',t:'Easy Returns',d:'7-day hassle-free exchange policy'},{icon:'📱',t:'WhatsApp Orders',d:'Order directly for a personal touch'}].map(i=>(
          <div key={i.t} className="text-center">
            <p className="text-3xl mb-3">{i.icon}</p>
            <p className="font-display text-base text-[#D4AF7A]">{i.t}</p>
            <p className="text-[11px] text-white/40 mt-1">{i.d}</p>
          </div>
        ))}
      </div>
    </div>
  );
}

function TestimonialsSection() {
  return (
    <section className="py-16 px-6 bg-white">
      <div className="max-w-[1200px] mx-auto">
        <div className="text-center mb-10">
          <p className="text-[10px] uppercase tracking-[0.3em] text-[#B8965A] mb-1">Reviews</p>
          <h2 className="font-display text-3xl text-[#2C3022]">Loved by <em className="text-[#B8965A]">Thousands</em></h2>
        </div>
        <div className="grid md:grid-cols-3 gap-6">
          {[
            {t:'"The lawn suit quality is amazing — embroidery exactly as shown. Will order again!"',a:'Sana R.',c:'Karachi'},
            {t:'"Bed sheet sets arrived quickly and exceeded expectations. Soft, vibrant, true to photos."',a:'Fatima K.',c:'Lahore'},
            {t:'"The bath towels are incredibly soft — better than what I\'ve seen in shops. Love ARSAM!"',a:'Amina B.',c:'Islamabad'},
          ].map(r=>(
            <div key={r.a} className="border border-[#E8E0D5] p-7">
              <p className="text-[#B8965A] tracking-widest mb-4 text-sm">★★★★★</p>
              <p className="font-display text-[15px] italic text-gray-600 leading-relaxed mb-5">{r.t}</p>
              <p className="text-[10px] uppercase tracking-widest text-gray-400">{r.a} — {r.c}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

function NewsletterSection() {
  const [email, setEmail] = useState('');
  const [done, setDone] = useState(false);
  return (
    <section className="bg-[#2C3022] py-16 px-6 text-center">
      <p className="text-[10px] uppercase tracking-[0.3em] text-[#D4AF7A] mb-2">Stay Connected</p>
      <h2 className="font-display text-3xl text-white font-light mb-2">Join the ARSAM Family</h2>
      <p className="text-white/40 text-[11px] tracking-wide mb-8">New arrivals, exclusive deals & seasonal collections</p>
      {done ? (
        <p className="text-[#D4AF7A] text-sm tracking-widest">Thank you for subscribing! ✨</p>
      ) : (
        <div className="flex max-w-md mx-auto">
          <input type="email" value={email} onChange={e=>setEmail(e.target.value)} placeholder="Your email address"
            className="flex-1 bg-white/10 border border-white/20 border-r-0 px-4 py-3.5 text-white text-sm placeholder-white/30 outline-none font-body" />
          <button onClick={()=>{if(email)setDone(true);}}
            className="bg-[#B8965A] px-6 text-white text-[10px] font-bold uppercase tracking-widest hover:bg-[#D4AF7A] transition-colors shrink-0">
            Subscribe
          </button>
        </div>
      )}
    </section>
  );
}

// ═══════════════════════════════════════════════════════════════
// FOOTER
// ═══════════════════════════════════════════════════════════════
function SiteFooter({ goTo }) {
  return (
    <footer className="bg-[#111] text-white/50 py-14 px-6">
      <div className="max-w-[1440px] mx-auto grid grid-cols-1 md:grid-cols-4 gap-10 mb-10">
        <div>
          <div className="flex items-center gap-3 mb-4">
            <img src={LOGO} alt="ARSAM" className="w-11 h-11 rounded-full object-cover border-2 border-[#B8965A]" />
            <div>
              <p className="font-display text-white text-sm tracking-wide">ARSAM</p>
              <p className="text-[8.5px] uppercase tracking-[0.2em] text-[#B8965A]">Fabrics & Textiles Ltd</p>
            </div>
          </div>
          <p className="text-xs leading-relaxed text-white/35 mb-4">Established 2020 · Premium Pakistani textiles for homes and wardrobes worldwide.</p>
          <div className="flex gap-3">
            {['📘','📸','📱'].map((icon,i)=>(
              <button key={i} className="w-8 h-8 border border-white/12 flex items-center justify-center text-sm hover:border-[#B8965A] transition-colors">{icon}</button>
            ))}
          </div>
        </div>
        <div>
          <h5 className="text-[10px] font-bold uppercase tracking-[0.25em] text-[#D4AF7A] mb-4">Shop</h5>
          <ul className="space-y-2.5 text-xs">
            {[['Women','women'],['Men','men'],['Children','kids'],['Fabrics','fabrics'],['Bed Sheets','bedsheets'],['Towels','towels'],['Sale','sale']].map(([l,id])=>(
              <li key={id}><button onClick={()=>goTo(id)} className="hover:text-[#D4AF7A] transition-colors">{l}</button></li>
            ))}
          </ul>
        </div>
        <div>
          <h5 className="text-[10px] font-bold uppercase tracking-[0.25em] text-[#D4AF7A] mb-4">Help</h5>
          <ul className="space-y-2.5 text-xs">
            {['Track My Order','Shipping Info','Returns & Exchange','Size Guide','WhatsApp Order'].map(l=>(
              <li key={l}><button className="hover:text-[#D4AF7A] transition-colors">{l}</button></li>
            ))}
          </ul>
        </div>
        <div>
          <h5 className="text-[10px] font-bold uppercase tracking-[0.25em] text-[#D4AF7A] mb-4">Company</h5>
          <ul className="space-y-2.5 text-xs">
            {['About ARSAM','Wholesale Enquiries','Careers','Privacy Policy'].map(l=>(
              <li key={l}><button onClick={l==='About ARSAM'?()=>goTo('about'):undefined} className="hover:text-[#D4AF7A] transition-colors">{l}</button></li>
            ))}
          </ul>
        </div>
      </div>
      <div className="border-t border-white/8 pt-6 flex flex-col md:flex-row items-center justify-between gap-4">
        <p className="text-[11px] text-white/20">© 2024 ARSAM Fabrics & Textiles Pvt. Ltd. · Est. 2020 · All Rights Reserved</p>
        <div className="flex gap-2 flex-wrap justify-center">
          {['JAZZCASH','EASYPAISA','BANK TRANSFER','COD'].map(b=>(
            <span key={b} className="border border-white/10 px-2.5 py-1 text-[9px] text-white/20 tracking-wide">{b}</span>
          ))}
        </div>
      </div>
    </footer>
  );
}

// ═══════════════════════════════════════════════════════════════
// SVG ICONS
// ═══════════════════════════════════════════════════════════════
function SearchIcon({ className='' }) {
  return <svg className={`w-5 h-5 ${className}`} fill="none" stroke="currentColor" strokeWidth={1.6} strokeLinecap="round" viewBox="0 0 24 24"><circle cx="11" cy="11" r="8"/><path d="m21 21-4.35-4.35"/></svg>;
}
function BagIcon({ className='' }) {
  return <svg className={`w-5 h-5 ${className}`} fill="none" stroke="currentColor" strokeWidth={1.6} strokeLinecap="round" viewBox="0 0 24 24"><path d="M6 2 3 6v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6l-3-4z"/><line x1="3" y1="6" x2="21" y2="6"/><path d="M16 10a4 4 0 0 1-8 0"/></svg>;
}
function XIcon({ size=18 }) {
  return <svg width={size} height={size} fill="none" stroke="currentColor" strokeWidth={1.8} strokeLinecap="round" viewBox="0 0 24 24"><path d="M18 6 6 18M6 6l12 12"/></svg>;
}
function HeartIcon({ size=16, filled=false }) {
  return <svg width={size} height={size} fill={filled?'currentColor':'none'} stroke="currentColor" strokeWidth={1.8} strokeLinecap="round" viewBox="0 0 24 24"><path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"/></svg>;
}
